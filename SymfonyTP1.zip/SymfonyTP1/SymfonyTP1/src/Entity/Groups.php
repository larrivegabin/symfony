<?php

namespace App\Entity;

use App\Repository\GroupsRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: GroupsRepository::class)]
#[ORM\Table(name: '`groups`')]
class Groups
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\OneToMany(mappedBy: 'groupTypes', targetEntity: groupTypes::class)]
    private Collection $groupTypes;

    public function __construct()
    {
        $this->groupTypes = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    /**
     * @return Collection<int, groupTypes>
     */
    public function getGroupTypes(): Collection
    {
        return $this->groupTypes;
    }

    public function addGroupType(groupTypes $groupType): static
    {
        if (!$this->groupTypes->contains($groupType)) {
            $this->groupTypes->add($groupType);
            $groupType->setGroupTypes($this);
        }

        return $this;
    }

    public function removeGroupType(groupTypes $groupType): static
    {
        if ($this->groupTypes->removeElement($groupType)) {
            // set the owning side to null (unless already changed)
            if ($groupType->getGroupTypes() === $this) {
                $groupType->setGroupTypes(null);
            }
        }

        return $this;
    }
}
