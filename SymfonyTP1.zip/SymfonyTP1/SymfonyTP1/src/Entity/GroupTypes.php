<?php

namespace App\Entity;

use App\Repository\GroupTypesRepository;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: GroupTypesRepository::class)]
class GroupTypes
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\ManyToOne(inversedBy: 'groupTypes')]
    private ?Groups $groupTypes = null;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getGroupTypes(): ?Groups
    {
        return $this->groupTypes;
    }

    public function setGroupTypes(?Groups $groupTypes): static
    {
        $this->groupTypes = $groupTypes;

        return $this;
    }
}
